import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

public class test1 {
  @Test(dataProvider = "addition")
 
  ///ADDITION
  public void addition(int num1,int num2,int exp) {
 int actual=num1+num2;
 Assert.assertEquals(exp,actual);
  }
 
 
  ///SUBTRACTION
  @Test(dataProvider="sub")
  public void subtraction(int num1,int num2,int exp) {
 int actual=num1-num2;
 Assert.assertEquals(exp,actual);
  }
 
  ///Multiplication
  @Test(dataProvider="multi")
  public void multiply(int num1,int num2,int exp) {
 int actual=num1*num2;
 Assert.assertEquals(exp,actual);
  }

  @DataProvider(name="addition")
  public Object[][] add() {
    return new Object[][] {
      new Object[] { 1, 2,3 },
      new Object[] { 2,3,5},
      new Object[] {4,2,6},
     
    };
  }
   
  @DataProvider(name="sub")
    public Object[][] sub() {
      return new Object[][] {
        new Object[] { 4,1,3 },
        new Object[] {9,5,4}
       
      };
  }
      @DataProvider(name="multi")
      public Object[][] mul() {
        return new Object[][] {
          new Object[] { 4,1,4},
          new Object[] {9,5,45}
         
        };
      }

   
  }