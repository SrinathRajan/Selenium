package com.example.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class test4 {
//	// directory where output is to be printed
//	ExtentSparkReporter spark = new ExtentSparkReporter("user/build/name/");
//	ExtentReports extent = new ExtentReports();
//	extent.AttachReporter(spark);

WebDriver driver;
@BeforeTest
public void before() {

	WebDriverManager.edgedriver().setup();
	  driver = new EdgeDriver();
}
  @Test
  public void t1() throws InterruptedException {
 String url="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
 driver.get(url);
      driver.manage().window().maximize();
      Thread.sleep(5000);
      System.out.println("t1");
      driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input")).sendKeys("Admin");
      Thread.sleep(2000);
      driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input")).sendKeys("admin123");
      Thread.sleep(2000);
      driver.findElement(By.xpath("/html/body/div/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
      Thread.sleep(5000);
      String gurl=driver.getCurrentUrl();
 String aurl="https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
// Assert.assertEquals(aurl, gurl
 Assert.assertEquals(aurl, gurl);
 System.out.println("t2");
  }
  @AfterTest
  public void aftertest() throws InterruptedException {
 Thread.sleep(7000);
 driver.quit();
 System.out.println("t3");
 System.out.println("t4");
  }

}