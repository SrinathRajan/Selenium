import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class test2 {
WebDriver driver;


@Test
public void TC_001() {
WebDriverManager.edgedriver().setup();
driver=new EdgeDriver();
driver.get("https://godaddy.com");

}

@Test
public void TC_002() {
WebDriverManager.edgedriver().setup();
driver=new EdgeDriver();
driver.get("https://godaddy.com");
}
@Test
public void TC_003() {
WebDriverManager.edgedriver().setup();
driver=new EdgeDriver();
driver.get("https://godaddy.com");
}
}