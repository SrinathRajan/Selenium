import org.testng.Assert;
import org.testng.annotations.Test;

public class test2 {
	int a=10,b=20,c;
//	c->result
  @Test
  public void add() {
	  c=a+b;
	  Assert.assertEquals(c, 10);
  }
}