import org.testng.annotations.Test;

public class test5 {
  @Test
  public void f() {
  }
}
